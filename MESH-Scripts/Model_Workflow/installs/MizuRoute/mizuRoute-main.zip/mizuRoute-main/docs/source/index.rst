Welcome to mizuRoute documentation!
=========================================

.. toctree::
   :maxdepth: 2

   Intro
   Input_data 
   Control_file
   seg_hru_param
   testCase

