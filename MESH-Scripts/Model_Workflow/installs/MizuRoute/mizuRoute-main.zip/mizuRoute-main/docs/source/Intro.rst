Introduction
============

mizuRoute is a river routing model framework that can host various river routing methods that transport runoff output from a hydrologic model along the river network. 
This document describes mizuRoute setting and input data. The routing schemes used in mizuRoute is described in `GMD paper <https://www.geosci-model-dev.net/9/2223/2016/>`_.

