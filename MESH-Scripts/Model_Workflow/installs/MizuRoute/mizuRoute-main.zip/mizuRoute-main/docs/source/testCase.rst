testCase data
================

Users are encouraged to test with `Cameo basin testCase <https://ral.ucar.edu/sites/default/files/public/projects/mizuroute-stand-alone-river-network-routing-model/testcase-cameo.tar_3.gz>`_.
