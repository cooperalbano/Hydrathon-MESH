# Contents in settings 
1. Control file (SAMPLE.control) 
